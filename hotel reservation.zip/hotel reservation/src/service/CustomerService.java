package service;

import model.Customer;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * perform actions related to customers
 * i.e. create a new customer, find a customer, Search and retrieve customer details
 *
 *  * Static reference from Bill pugh Singleton implementation referenced from:
 *  * https://www.journaldev.com/1377/java-singleton-design-pattern-best-practices-examples
 */
public class CustomerService {

    final Map<String,Customer> findMyCustomers = new HashMap<>();
    private static CustomerService customerDetails = null;
    private CustomerService(){}

    public static CustomerService getInstance(){

        if(customerDetails == null)
        {
            customerDetails = new CustomerService();
        }

        return customerDetails;
    }

    /**
     * Register new customer details
     *
     * @param email customer email address
     * @param firstName customer FirstName
     * @param lastName customer Surname
     */

    public void addCustomer(String email, String firstName, String lastName){
        Customer newAddition = new Customer(firstName, lastName, email);
        findMyCustomers.putIfAbsent(email, newAddition);
    }

    /**
     * Search and retrieve customer details
     *
     * @param customerEmail to search for customer details
     * @return existing customer or null where not exists
     */
    public Customer getCustomer(String customerEmail){
       return findMyCustomers.get(customerEmail);
    }

    /**
     * Search and retrieve all customer records
     * @return all existing customer records
     */
    public Collection<Customer> getAllCustomers(){
        return findMyCustomers.values();
    }
}

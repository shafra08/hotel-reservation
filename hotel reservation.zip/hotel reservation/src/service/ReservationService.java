package service;

import model.IRoom;
import model.Reservation;
import model.Room;
import model.Customer;
import java.util.*;

/**
 * Perform actions related to making reservations
 *
 * Static reference from Bill pugh Singleton implementation referenced from:
 * https://www.journaldev.com/1377/java-singleton-design-pattern-best-practices-examples
 *
 */
public class ReservationService {
    final HashMap<String,Room> roomStatus = new HashMap<>();
    final HashMap<ArrayList<Date>, Reservation> isReserved = new HashMap<>();
    private ArrayList<Date> dateRangeToAdd;
    private static ReservationService reserveCache = null;
    private ReservationService(){}

    public static ReservationService getInstance(){
        if(reserveCache == null){
            reserveCache = new ReservationService();
        }

        return  reserveCache;
    }


    /**
     * Adds a new room to the hotel
     *
     * @param room to be added to Hotel catalogue
     */
    public void addRoom(IRoom room){
        Room emptyRoom = new Room(room.getRoomNumber(),room.getRoomPrice(),room.getRoomType());

        roomStatus.putIfAbsent(emptyRoom.getRoomNumber(), emptyRoom);
    }

    /**
     * Search and retrieve room details based on room number
     *
     * @param roomId used to Search for room
     * @return existing room or null if not exits
     */
    public IRoom getARoom(String roomId){
        return roomStatus.get(roomId);
    }

    /**
     * Make a reservation for an existing customer based on existing dates
     * @param customer making the reservation
     * @param room to reserve
     * @param checkInDate Intended checkIn Date
     * @param checkOutDate Intended checkout Date
     * @return reservation details
     */

    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate){
        Reservation toReserve = new Reservation(customer,room,checkInDate,checkOutDate);
        dateRangeToAdd = new ArrayList<>();

        dateRangeToAdd.add(checkInDate);
        dateRangeToAdd.add(checkOutDate);

        isReserved.putIfAbsent(dateRangeToAdd, toReserve);

        return toReserve;

    }

    /**
     *
     * @param checkInDate Intended checkIn date
     * @param checkOutDate Intended checkOut date
     * @return rooms available withing given dates
     */

    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {
        ArrayList<IRoom> getAvailableRooms = new ArrayList<>(roomStatus.values());

        Iterator<ArrayList<Date>> iterate = isReserved.keySet().iterator();

        while (iterate.hasNext()) {
            dateRangeToAdd = new ArrayList<>();
            Date reserveDateIn;
            Date reserveDateOut;

            dateRangeToAdd.addAll(iterate.next());

            reserveDateIn = dateRangeToAdd.get(0);
            reserveDateOut = dateRangeToAdd.get(1);

            if(checkInDate.before(reserveDateIn) && checkOutDate.before(reserveDateIn)){
                System.out.println();
            }
            else if(checkInDate.after(reserveDateOut) && checkOutDate.after(reserveDateOut)) {
                System.out.println();
            }
            else
            {
                getAvailableRooms.remove(isReserved.get(dateRangeToAdd).getRoom());
            }
        }
        return getAvailableRooms;
    }

    /**
     * Search and retrieve customers booking
     * @param customer to query for reservation details
     * @return existing reservation for customer ot null
     */

    public Collection<Reservation> getCustomersReservation(Customer customer){
        Iterator<ArrayList<Date>> findMyBooking = isReserved.keySet().iterator();
        ArrayList<Reservation> retrieveBookings = new ArrayList<>();


        while (findMyBooking.hasNext()){
            dateRangeToAdd = new ArrayList<>();
            dateRangeToAdd.addAll(findMyBooking.next());

            if(isReserved.get(dateRangeToAdd).getCustomer().equals(customer)){
                retrieveBookings.add(isReserved.get(dateRangeToAdd));
            }

        }
        return retrieveBookings;
    }

    /**
     * Retrieve existing reservations
     */

    public void printAllReservations(){
        Iterator<Reservation> allReserved = isReserved.values().iterator();

        while (allReserved.hasNext()){
            System.out.println(allReserved.next());
        }
    }

    /**
     * Search and retrieve all existing rooms
     * @return existing rooms
     */

    public Collection<IRoom> getAllRooms(){
        return new ArrayList<>(roomStatus.values());
    }

}

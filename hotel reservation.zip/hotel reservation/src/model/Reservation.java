package model;

import java.util.Date;
import java.util.Objects;

/**
 * Class with Reservation attributes
 */
public class Reservation {
    private final Customer customer;
    private final IRoom room;
    private final Date checkInDate;
    private final Date checkOutDate ;

    public Reservation(){
        this.customer = null;
        this.room = null;
        this.checkInDate = new Date();
        this.checkOutDate = new Date();

    }
    public Reservation(Customer customer, IRoom room,Date checkInDate, Date checkOutDate){
        this.customer = customer;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    public Customer getCustomer() {
        return customer;
    }

    public IRoom getRoom() {
        return room;
    }

    public Date getCheckInDate() {
        return checkInDate;
    }

    public Date getCheckOutDate() {
        return checkOutDate;
    }


    @Override
    public String toString() {
        return "Reservation{" +
                "customer=" + getCustomer() +
                ", room=" + getRoom() +
                ", checkInDate=" + getCheckInDate() +
                ", checkOutDate=" + getCheckOutDate() +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Reservation)) return false;
        Reservation that = (Reservation) o;
        return Objects.equals(customer, that.customer) && Objects.equals(room, that.room) && Objects.equals(checkInDate, that.checkInDate) && Objects.equals(checkOutDate, that.checkOutDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(customer, room, checkInDate, checkOutDate);
    }
}

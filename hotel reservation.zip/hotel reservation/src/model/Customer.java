package model;

import java.util.Objects;
import java.util.regex.Pattern;

/**
 * Class with customer attributes
 */
public class Customer {
    private final String firstName;
    private final String lastName;
    private final String email;

    public Customer(String firstName,String lastName, String email){
        String emailValid = "^(.+)@(.+).(.com)$";
        Pattern emailPattern = Pattern.compile(emailValid);
        if(!emailPattern.matcher(email).matches()){
            throw new IllegalArgumentException("Invalid email address");
        }
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;

    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }


    public String toString(){
        return "{Firstname: "+getFirstName() +
                "\tLastname: "+getLastName() +
                "\t email: "+getEmail() +"}";
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Customer)) return false;
        Customer customer = (Customer) o;
        return Objects.equals(firstName, customer.firstName) && Objects.equals(lastName, customer.lastName) && Objects.equals(email, customer.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, email);
    }
}

package model;

import java.util.Objects;

/**
 * Class with room attributes
 */
public class Room implements IRoom{
    private final String roomNumber;
    private final Double price;
    private final RoomType enumeration;


    public Room(){
        this.roomNumber = "";
        this.price = 0.0;
        this.enumeration = null;
    }
    public Room(String roomNumber, Double price, RoomType roomType) {
        this.roomNumber = roomNumber;
        this.price = price;
        this.enumeration = roomType;
    }

    public Double getPrice() {
        return price;
    }

    public RoomType getEnumeration() {
        return enumeration;
    }

    @Override
    public String getRoomNumber() {
        return this.roomNumber;
    }

    @Override
    public Double getRoomPrice() {
        return this.price;
    }

    @Override
    public RoomType getRoomType() {
        return this.getEnumeration();
    }

    @Override
    public boolean isFree() {
        return false;
    }

    @Override
    public String toString() {
        return "Room{" +
                "roomNumber='" + getRoomNumber() + '\'' +
                ", price=" + getPrice() +
                ", enumeration=" + getEnumeration() +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Room)) return false;
        Room room = (Room) o;
        return Objects.equals(roomNumber, room.roomNumber) && Objects.equals(price, room.price) && enumeration == room.enumeration;
    }

    @Override
    public int hashCode() {
        return Objects.hash(roomNumber, price, enumeration);
    }
}

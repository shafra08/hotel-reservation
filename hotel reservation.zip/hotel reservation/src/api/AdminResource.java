package api;

import model.Customer;
import model.IRoom;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * API for admin related tasks
 *
 *  * Static reference from Bill pugh Singleton implementation referenced from:
 *  * https://www.journaldev.com/1377/java-singleton-design-pattern-best-practices-examples
 */
public class AdminResource {
    CustomerService customerDetails = CustomerService.getInstance();
    ReservationService reserveCache = ReservationService.getInstance();

    private static AdminResource adminR = null;
    private AdminResource(){}


    public static AdminResource getInstance(){
        if(adminR == null){
            adminR = new AdminResource();
        }

        return adminR;
    }


    /**
     * Search for existing customer and return their details
     *
     * @param email customer email to search
     * @return details of existing customer or null
     */
    public Customer getCustomer(String email){
        return customerDetails.getCustomer(email);
    }

    /**
     * Add a new room to the hotel catalogue
     *
     * @param rooms accepts attributes for the room to be added
     */
    public void addRoom(List<IRoom> rooms){
        Iterator<IRoom> newAddition = rooms.stream().iterator();

        while (newAddition.hasNext()) {
            reserveCache.addRoom(newAddition.next());
        }
    }

    /**
     * Search and retrieve a list of all rooms in the hotel and their attributes
     *
     * @return all existing rooms
     */
    public Collection<IRoom> getAllRooms(){
        return reserveCache.getAllRooms();
    }

    /**
     * Search and retrieve a list of all customer details in record
     *
     * @return all existing customer records
     */

    public Collection<Customer> getAllCustomers(){
        return customerDetails.getAllCustomers();
    }

    /**
     * Retrieve all reservations
     */

    public void displayAllReservations(){
        reserveCache.printAllReservations();
    }


}

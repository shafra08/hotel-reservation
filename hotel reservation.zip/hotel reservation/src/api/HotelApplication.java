package api;

import java.util.Scanner;

/**
 *  Run hotel reservation application
 * */

public class HotelApplication {
    static int userSelection;

    public static void main(String [] args){
        validateHotelReservationApp();

    }

    /**
     * Perform actions based on user selection on the menu
     */
    public static void validateHotelReservationApp(){
        Scanner testMenuInput;
        String testAll = "";

        MainMenu testMenu = new MainMenu();
        AdminMenu adminTest = new AdminMenu();

        try{
            do{
                testMenu.displayMainMenu();
                System.out.println("Select an option:");
                testMenuInput = new Scanner(System.in);
                userSelection = testMenuInput.nextInt();

                testMenu.setUserOption(userSelection);
                testMenu.executeUserSelection(testMenu.getUserOption());

                if(testMenu.getUserOption() == 4){
                    do{
                        adminTest.displayAdminMenu();
                        System.out.println("Select an option:");
                        testMenuInput = new Scanner(System.in);
                        userSelection = testMenuInput.nextInt();

                        adminTest.setAdminOption(userSelection);
                        adminTest.executeAdminSelection(adminTest.getAdminOption());

                        if(adminTest.getAdminOption() == 5){
                            testMenu.displayMainMenu();
                            break;
                        }

                        System.out.println("Press 'Y' to continue in admin menu, 'N' to Exit admin menu )");
                        testMenuInput = new Scanner(System.in);
                        testAll = testMenuInput.next();
                    }while (!testAll.equalsIgnoreCase("N"));
                }

                if(testMenu.getUserOption() == 5){
                    break;
                }
                System.out.println("Press 'Y' to continue in main menu, 'N' to Exit main menu ");
                testMenuInput = new Scanner(System.in);
                testAll = testMenuInput.next();
            }while (!testAll.equalsIgnoreCase("N"));

        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            if(userSelection !=5 && !testAll.equalsIgnoreCase("N")){
                validateHotelReservationApp();
            }
        }
    }
}

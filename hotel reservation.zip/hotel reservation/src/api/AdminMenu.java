package api;

import model.IRoom;
import model.Room;
import model.RoomType;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 * displays and loads Admin options for Hotel Reservation application
 *
 */
public class AdminMenu {
    private int adminOption;
    AdminResource resourceA  = AdminResource.getInstance();

    public void displayAdminMenu(){
        System.out.println("\nAdmin Menu:");

        for(int i=0; i<30; i++){
            System.out.print("_");
        }
        System.out.println();
        System.out.println("1. See all Customers");
        System.out.println("2. See all Rooms");
        System.out.println("3. See all Reservations ");
        System.out.println("4. Add a room ");
        System.out.println("5. Back to Main Menu");
    }

    /**
     * method to access adminOption variable
     *
     * @return the user specified option
     */
    public int getAdminOption() {
        return adminOption;
    }

    /**
     * method to set the value of the adminOption variable
     */

    public void setAdminOption(int adminOption) {
        this.adminOption = adminOption;
    }

    /**
     * method to execute actions corresponding to user selection in admin menu options
     */

    public final void executeAdminSelection(int adminOption){
        String [] roomNumber;
        double [] price;
        int [] roomType;
        Scanner userEntry;
        String [] loopSource;
        int i, invalidRType;
        List<IRoom> newRoom;

        try{
            switch (adminOption){
                case 1:
                    System.out.println(resourceA.getAllCustomers());
                    break;
                case 2:
                    System.out.println(resourceA.getAllRooms());
                    break;
                case 3:
                    resourceA.displayAllReservations();
                    break;
                case 4:
                    System.out.println("Enter room number(can enter multiple room numbers with comma separated list)");
                    userEntry = new Scanner(System.in);
                    roomNumber = userEntry.next().split(",");

                   do{
                       System.out.println("Enter price per night for "+roomNumber.length+" room(s) entered above (comma separated list)");
                       userEntry = new Scanner(System.in);
                       loopSource = userEntry.next().split(",");
                   }while(loopSource.length != roomNumber.length);

                    price= new double[loopSource.length];

                    for(i = 0; i< loopSource.length; i++){
                        price[i] = Double.parseDouble(loopSource[i]);
                    }

                    do{
                        invalidRType = 0;
                        System.out.println("Enter room type(1 for Single bed, 2 for Double bed) for"+
                                roomNumber.length+" room(s) entered above (comma separated list)");
                        userEntry = new Scanner(System.in);
                        loopSource = userEntry.next().split(",");

                        for(String rType:loopSource){
                            if(!rType.equalsIgnoreCase("1") && !rType.equalsIgnoreCase("2")){
                                invalidRType = 1;
                                break;
                            }
                        }
                    }while((loopSource.length != roomNumber.length) || (invalidRType==1));

                    roomType = new int[loopSource.length];

                    for(i = 0; i< loopSource.length; i++){
                        roomType[i] = Integer.parseInt(loopSource[i]);
                    }

                    for(i = 0; i< loopSource.length; i++){
                        newRoom = new ArrayList<>();
                        newRoom.add(new Room(roomNumber[i],price[i], roomType[i] == 1? RoomType.SINGLE: RoomType.DOUBLE));
                        resourceA.addRoom(newRoom);
                    }
                    break;
                case 5:
                    break;
                default:
                    displayAdminMenu();
            }

        }
        catch(Exception e) {
            System.out.println("Invalid Input");
            e.printStackTrace();
        }
    }


}

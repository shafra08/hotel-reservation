package api;

import model.Customer;
import model.IRoom;
import model.Reservation;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.Date;

/**
 * API for main menu - customer related tasks
 *
 *  * Static reference from Bill pugh Singleton implementation referenced from:
 *  * https://www.journaldev.com/1377/java-singleton-design-pattern-best-practices-examples
 *
 */
public class HotelResource {
    CustomerService customerDetails = CustomerService.getInstance();
    ReservationService reserveCache = ReservationService.getInstance();

    private static HotelResource hr = null;
    private HotelResource(){}

    public static HotelResource getInstance(){
        if(hr == null){
            hr = new HotelResource();
        }
        return hr;
    }

    /**
     * Search and retrieve specific customer details
     *
     * @param email to search for existing customer
     * @return customer record based on email provided
     */
    public Customer getCustomer(String email){
        return customerDetails.getCustomer(email);
    }

    /**
     * Register new customer details
     *
     * @param email customer email address
     * @param firstName customer FirstName
     * @param lastName customer Surname
     */
    public void createACustomer(String email, String firstName, String lastName){
        customerDetails.addCustomer(email, firstName, lastName);
    }

    /**
     * Search and retrieve room details given a room number
     */
    public IRoom getRoom(String roomNumber){
        return reserveCache.getARoom(roomNumber);
    }

    /**
     * Reserve a room based on specific dates
     * @param customerEmail to identify customer making reservation
     * @param room to reserve
     * @param checkInDate Date in
     * @param checkOutDate Date out
     * @return customer reservation
     */
    public Reservation bookARoom(String customerEmail, IRoom room, Date checkInDate, Date checkOutDate){
        Customer findCustomer = customerDetails.getCustomer(customerEmail);

        return reserveCache.reserveARoom(findCustomer,room,checkInDate,checkOutDate);
    }

    /**
     * Search and Retrieve existing customer reservation based on email provided
     *
     * @param customerEmail to identify customer
     * @return existing reservation
     */
    public Collection<Reservation> getCustomersReservations(String customerEmail){
        Customer findCustomer = customerDetails.getCustomer(customerEmail);
        return reserveCache.getCustomersReservation(findCustomer);
    }

    /**
     * Get a room based on user provided dates
     *
     * @param checkIn Date intended for check in
     * @param checkOut Date intended for check out
     * @return available rooms for dates provided by customer
     */
    public Collection<IRoom> findARoom(Date checkIn, Date checkOut){
        return reserveCache.findRooms(checkIn,checkOut);
    }
}

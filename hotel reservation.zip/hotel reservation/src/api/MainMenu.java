package api;

import model.IRoom;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * displays and loads main menu options for Hotel Reservation application
 */
public class MainMenu {
    private int userOption;
    HotelResource ResourceH = HotelResource.getInstance();
    AdminResource resourceA  = AdminResource.getInstance();

    public void displayMainMenu(){

        System.out.println("\nMain Menu:");

        for(int i=0; i<30; i++){
            System.out.print("_");
        }
        System.out.println();
        System.out.println("1. Find and reserve a room");
        System.out.println("2. See my reservations");
        System.out.println("3. Create an account ");
        System.out.println("4. Admin ");
        System.out.println("5. Exit");
    }

    /**
     * method to access userOption variable
     *
     * @return the user specified option
     */

    public int getUserOption() {
        return userOption;
    }

    /**
     * method to set the value of the userOption variable
     */


    public void setUserOption(int userOption) {
        this.userOption = userOption;
    }
    /**
     * method to execute actions corresponding to user selection in main menu options
     */


    public final void executeUserSelection(int userOption){
        Scanner userEntry;
        String [] bookedDates;
        int year, month, day;
        int i,j;
        String [] splitDates;
        Date checkInDate;
        Date checkOutDate;
        Calendar setBookingDate = null;
        String commitToBooking;
        String email, roomNo, firstName, lastName;
        SimpleDateFormat checkFormat = new SimpleDateFormat("MM/dd/yyyy");
        ArrayList<IRoom> findRoomResponse;


        try {
            switch (userOption) {
                case 1:
                do {
                    i = 0;
                    checkInDate = new Date();
                    checkOutDate = new Date();

                    System.out.println("Please Enter desired checkIn and checkOut dates (format mm/dd/yyyy comma separated)");
                    userEntry = new Scanner(System.in);
                    bookedDates = userEntry.next().split(",");

                    for (String bookDate : bookedDates) {
                        j = 0;
                        year = 0;
                        month = 0;
                        day = 0;
                        setBookingDate = Calendar.getInstance();

                        if (checkFormat.parse(bookDate) == null || bookDate.isEmpty()) {
                            System.out.println("Invalid date format");
                            break;
                        }

                        splitDates = bookDate.split("/");
                        for (String datePortion : splitDates) {
                            switch (j) {
                                case 0 -> month = Integer.parseInt(datePortion);
                                case 1 -> day = Integer.parseInt(datePortion);
                                case 2 -> year = Integer.parseInt(datePortion);
                            }
                            j++;
                        }
                        switch (i) {
                            case 0 -> {
                                setBookingDate.set(year, (month - 1), day);
                                checkInDate = setBookingDate.getTime();
                            }
                            case 1 -> {
                                setBookingDate.set(year, (month - 1), day);
                                checkOutDate = setBookingDate.getTime();
                            }
                        }
                        i++;
                    }
                    if(checkInDate.after(checkOutDate) && bookedDates.length == 2){
                        System.out.println("Check Out date"+checkOutDate+ "cannot be before Check In date"+ checkInDate);
                    }
                }while(bookedDates.length != 2 || checkInDate.after(checkOutDate));


                   if(resourceA.getAllRooms().isEmpty()){
                       System.out.println("No Available rooms, please contact system administrator");
                       break;
                   }
                   else{
                       findRoomResponse = (ArrayList<IRoom>) ResourceH.findARoom(checkInDate,checkOutDate);
                   }


                    while(findRoomResponse.isEmpty()){
                        //add 7 days to search dates to get next available booking dates
                        setBookingDate.clear();
                        setBookingDate.setTime(checkInDate);
                        setBookingDate.add(Calendar.DAY_OF_MONTH, 7);
                        checkInDate = setBookingDate.getTime();

                        setBookingDate.clear();
                        setBookingDate.setTime(checkOutDate);
                        setBookingDate.add(Calendar.DAY_OF_MONTH, 7);
                        checkOutDate = setBookingDate.getTime();

                        findRoomResponse = (ArrayList<IRoom>) ResourceH.findARoom(checkInDate,checkOutDate);

                    }

                    System.out.println("\n Available Rooms:\t" + findRoomResponse +"\n between dates: "+
                            checkInDate+"\t"+checkOutDate);

                    do{
                        System.out.println("Do you wish to reserve a room based on available dates above?"+
                                "'Y' for yes, 'N' for no:");
                        userEntry = new Scanner(System.in);
                        commitToBooking = userEntry.next();

                        if (commitToBooking.equalsIgnoreCase("Y") || commitToBooking.equalsIgnoreCase("N")){
                            break;
                        }
                        else {
                            System.out.println("Invalid Input");
                        }
                    }while (!commitToBooking.equalsIgnoreCase("Y") || !commitToBooking.equalsIgnoreCase("N") );

                    if(commitToBooking.equalsIgnoreCase("Y")){

                        System.out.println("Do you have an account with the hotel? 'Y' for yes, 'N' for no:");
                        userEntry = new Scanner(System.in);
                        if (userEntry.next().equalsIgnoreCase("Y")) {

                            System.out.println("Enter customer email for reservation (i.e.testuser@gmail.com):");
                            userEntry = new Scanner(System.in);

                            email = userEntry.next();

                            if(resourceA.getCustomer(email)==null){
                                System.out.println("Create customer account to proceed");
                                break;
                            }

                            do {

                                System.out.println("Enter preferred room Number (Availability shown above):");
                                userEntry = new Scanner(System.in);

                                roomNo = userEntry.next();
                            }while (!findRoomResponse.contains(ResourceH.getRoom(roomNo)));



                            System.out.println(ResourceH.bookARoom(email,ResourceH.getRoom(roomNo),checkInDate,checkOutDate));
                        }
                        else{
                            System.out.println("Kindly create an Account to proceed:");
                            break;
                        }
                    }
                    else{
                        break;
                    }
                    break;
                case 2:
                    System.out.println("Enter customer email used for reservation (i.e.testuser@gmail.com):");
                    userEntry = new Scanner(System.in);
                    email = userEntry.next();

                    System.out.println(ResourceH.getCustomersReservations(email));
                    break;

                case 3:
                    System.out.println("Enter customer Email (i.e.testuser@gmail.com):");
                    userEntry = new Scanner(System.in);
                    email = userEntry.next();

                    System.out.println("Enter first name:");
                    userEntry = new Scanner(System.in);
                    firstName = userEntry.next();

                    System.out.println("Enter last name:");
                    userEntry = new Scanner(System.in);
                    lastName = userEntry.next();

                    ResourceH.createACustomer(email,firstName,lastName);
                    System.out.println(ResourceH.getCustomer(email));
                    break;
                case 4:
                       AdminMenu superDoer = new AdminMenu();
                       superDoer.displayAdminMenu();
                       break;
                case 5:
                    break;
                default:
                    displayMainMenu();
            }
        }
        catch (Exception e){
            e.printStackTrace();
            System.out.println("\n Invalid Input");
        }
    }
}
